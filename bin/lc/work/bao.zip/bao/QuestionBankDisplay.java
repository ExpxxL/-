package lc.work.bao;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableColumnModel;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

class QuestionBankDisplay extends JFrame {
    private ArrayList<Question> questionBank;
    private DefaultTableModel tableModel;
    private JTable table;
    
    private JButton prevButton;
    private JButton nextButton;
    private JTextField searchField;
    private JButton showButton;
    private JButton produceButton;
    private JButton singleChoiceButton;
    private JButton multipleChoiceButton;
    
    private Mysql con;
    
    public QuestionBankDisplay() {
    	//ArrayList<Question> questionBank
    	con = new Mysql();
        this.questionBank = con.getSingle_choiceQuestionBank();

        // 设置窗口标题
        setTitle("题库展示");

        // 创建表格
        tableModel = new DefaultTableModel();
        tableModel.addColumn("题目内容");
        tableModel.addColumn("答案");
        tableModel.addColumn("题目类型");

        table = new JTable(tableModel);

        // 在此处添加设置列宽的代码
        TableColumnModel columnModel = table.getTableHeader().getColumnModel();
        columnModel.getColumn(0).setPreferredWidth(columnModel.getColumn(0).getPreferredWidth() * 10);
        columnModel.getColumn(1).setPreferredWidth(columnModel.getColumn(1).getPreferredWidth() * 1);
        columnModel.getColumn(2).setPreferredWidth(columnModel.getColumn(2).getPreferredWidth() * 1);

        // 获取行高度
        int originalRowHeight = table.getRowHeight();
        // 设置行高度为原来的两倍
        table.setRowHeight(originalRowHeight * 2);

        // 设置自动换行
        table.getColumnModel().getColumn(0).setCellRenderer(new MultilineTableCellRenderer());

        
        // 初始化表格数据
        initializeTableData();

        // 创建功能按钮
        prevButton = new JButton("上一页");
        nextButton = new JButton("下一页");
        searchField = new JTextField(20);
        JButton searchButton = new JButton("搜索");
        showButton = new JButton("题库展示");
        produceButton = new JButton("出卷界面");
        singleChoiceButton = new JButton("显示单选题");
        multipleChoiceButton = new JButton("显示多选题");


        // 添加事件监听器
        prevButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
            	showPreviousPage();
            }
        });
        nextButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
            	showNextPage();
            }
        });
        searchButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
            	searchQuestions();
            }
        });
        singleChoiceButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
            	singleChoiceQuestion();
            }
        });
        multipleChoiceButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
            	multipleChoiceQuestionBank();
            }
        });
        showButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
            	showQuestionBank();
            }
        });
        produceButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
            	produceQuestionBank();
            }
        });

        // 创建布局
        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new GridLayout(2, 2));
        //buttonPanel.add(new JLabel("搜索："));
        buttonPanel.add(searchField);
        buttonPanel.add(searchButton);
        buttonPanel.add(prevButton);
        buttonPanel.add(nextButton);
        
        JPanel functionBar1=new JPanel();
        functionBar1.setLayout(new GridLayout(20,1));
        functionBar1.add(showButton);
        functionBar1.add(produceButton);
        functionBar1.add(singleChoiceButton);
        functionBar1.add(multipleChoiceButton);
        

        // 添加组件到窗口
        add(functionBar1, BorderLayout.WEST);
        add(new JScrollPane(table), BorderLayout.CENTER);
        add(buttonPanel, BorderLayout.SOUTH);

        // 设置窗口属性
        setSize(1000, 800);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);  // 关闭该窗口不退出整个应用
        setLocationRelativeTo(null);
        setVisible(true);
    }

    //按钮实现
    private void initializeTableData() {
        // 将题库数据添加到表格
        for (Question question : questionBank) {
            tableModel.addRow(new Object[]{question.getContent(), question.getAnswer(), question.getType()});
        }
    }

    private void showPreviousPage() {
        // 实现上一页的逻辑
        // 可以根据需要更新表格数据
        // 这里只是一个示例
        JOptionPane.showMessageDialog(this, "上一页功能待实现");
    }

    private void showNextPage() {
        // 实现下一页的逻辑
        // 可以根据需要更新表格数据
        // 这里只是一个示例
        JOptionPane.showMessageDialog(this, "下一页功能待实现");
    }

    private void searchQuestions() {
        // 实现搜索题目的逻辑
        // 可以根据输入的关键字更新表格数据
    	
        String keyword = searchField.getText().toLowerCase();
        for (int i = tableModel.getRowCount() - 1; i >= 0; i--) {
            if (!tableModel.getValueAt(i, 0).toString().toLowerCase().contains(keyword)) {
                tableModel.removeRow(i);
            }
        }
    }
    private void singleChoiceQuestion() {
    	questionBank = con.getSingle_choiceQuestionBank();
        updateTableData();
    }
    private void multipleChoiceQuestionBank() {
    	questionBank = con.getMultiple_choiceQuestionBank1();
        updateTableData();
    }
    private void showQuestionBank() {
        // 实现搜索题目的逻辑
        // 可以根据输入的关键字更新表格数据
    	
        String keyword = searchField.getText().toLowerCase();
        for (int i = tableModel.getRowCount() - 1; i >= 0; i--) {
            if (!tableModel.getValueAt(i, 0).toString().toLowerCase().contains(keyword)) {
                tableModel.removeRow(i);
            }
        }
    }
    private void produceQuestionBank() {
        // 实现搜索题目的逻辑
        // 可以根据输入的关键字更新表格数据
    	
        String keyword = searchField.getText().toLowerCase();
        for (int i = tableModel.getRowCount() - 1; i >= 0; i--) {
            if (!tableModel.getValueAt(i, 0).toString().toLowerCase().contains(keyword)) {
                tableModel.removeRow(i);
            }
        }
    }
    
    // 通用的更新表格数据方法
    private void updateTableData() {
        // 清空表格数据
        tableModel.setRowCount(0);

        // 将题库数据添加到表格
        for (Question question : questionBank) {
            tableModel.addRow(new Object[]{question.getContent(), question.getAnswer(), question.getType()});//addRow接受Object[]数组作为参数
        }
    }

    
    public static void main(String[] args) {
        // 示例用法
        SwingUtilities.invokeLater(() -> {
            // 假设已有一个题库
            ArrayList<Question> questionBank = new ArrayList<>();
            questionBank.add(new Question("问题1", "答案1", "单选题"));
            questionBank.add(new Question("问题2", "答案2", "多选题"));
            questionBank.add(new Question("问题3", "答案3", "判断题"));

            new QuestionBankDisplay();
        });
    }
}
