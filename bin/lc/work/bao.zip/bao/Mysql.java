package lc.work.bao;

import java.sql.*;
import java.util.ArrayList;

class Mysql {
	//数据库用户名和密码
	private static final String USER = "root";
	private static final String PASS = "123456";
    
    //数据库操作变量
    static PreparedStatement ps = null;
    static ResultSet rs=null;
    static Statement stmt = null;
    
    // MySQL 8.0 以下版本 - JDBC 驱动名及数据库 URL
    private static final String JDBC_DRIVER = "com.mysql.jdbc.Driver";  
    private static final String DB_URL = "jdbc:mysql://localhost:3306/project";
    
    static Connection conn = null;//数据库连接

    //static修饰的代码块被称为静态代码块。
    //static {
    	//static在这里意味只执行一次
    Mysql(){
        try {
            if (conn == null) {
                //mysql
                Class.forName(JDBC_DRIVER);
                conn = DriverManager.getConnection(DB_URL,USER,PASS);
             }
        }catch(SQLException se){
            // 处理 JDBC 错误
            se.printStackTrace();
        } catch (Exception ex) {
        	// 处理 Class.forName 错误
            ex.printStackTrace();
        }
    //}
    }
    public ResultSet login(){
    	String sql ="SElECT username,password FROM user_information";
		try {
			stmt=conn.createStatement();
			rs = stmt.executeQuery(sql);
		} catch (SQLException e) {
			// TODO 自动生成的 catch 块
			e.printStackTrace();
		}
		return rs;
    }
    public ArrayList<Question> getSingle_choiceQuestionBank() {
    	//题库界面展示
        ArrayList<Question> questionBank = new ArrayList<>();
        String sql = "SELECT topic,answer FROM Single_choice";
        String type="单选题";
        try {
            ps = conn.prepareStatement(sql);
            rs = ps.executeQuery();

            while (rs.next()) {
                String content = rs.getString("topic");//获取题目
                String answer = rs.getString("answer"); // 获取答案

                Question question = new Question(content, answer, type);
                questionBank.add(question);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                if (ps != null) {
                    ps.close();
                }
                if (rs != null) {
                    rs.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return questionBank;
    }
    
    public ArrayList<Question> getMultiple_choiceQuestionBank1() {
    	//题库界面展示
        ArrayList<Question> questionBank = new ArrayList<>();
        String sql = "SELECT topic,answer FROM multiple_choice";
        String type="多选题";
        try {
            ps = conn.prepareStatement(sql);
            rs = ps.executeQuery();

            while (rs.next()) {
                String content = rs.getString("topic");//获取题目
                String answer = rs.getString("answer"); // 获取答案

                Question question = new Question(content, answer, type);
                questionBank.add(question);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                if (ps != null) {
                    ps.close();
                }
                if (rs != null) {
                    rs.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return questionBank;
    }
    
    
    
    //获取查询结果集
    public ResultSet getRs(String sql){
        if (sql.toLowerCase().indexOf("select")!=-1){
            try{
                stmt = conn.createStatement();
                rs = stmt.executeQuery(sql);
            }catch (SQLException e){
                e.printStackTrace();
            }
        }
        return rs;
    }
    public void insert(String sql) throws SQLException {
    	ps = conn.prepareStatement(sql);
    	ps.execute();
    	ps.close();
    }
    
    //修改数据
    public int dataUpdate(String sql) throws SQLException
    {
        Statement statement=conn.createStatement();
        int result=statement.executeUpdate(sql);
        statement.close();
        return result;
    }
    public void finalize() throws SQLException//善后操作
    {
        rs.close();
        stmt.close();
    }
}
