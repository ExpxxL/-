package lc.work.bao;

import javax.swing.*;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableCellRenderer;
import javax.swing.table.TableColumnModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.util.ArrayList;


public class QuestionBankManagementSystem extends JFrame {
    private ArrayList<Question> questionBank;
    private Mysql con;
    private JTable table;
    private DefaultTableModel tableModel;
    private JTextField questionField;
    private JTextField answerField;
    private JComboBox<String> questionTypeComboBox;
    private String content;
    private String answer;
    private String type;
    public QuestionBankManagementSystem() {
        // 初始化题库
        questionBank = new ArrayList<>();

        con = new Mysql();
        
        // 设置窗口标题
        setTitle("试卷题库管理系统");

        // 登录
        new Login();

        // 创建表格
        tableModel = new DefaultTableModel();
        tableModel.addColumn("题目内容");
        tableModel.addColumn("答案");
        tableModel.addColumn("题目类型");

        table = new JTable(tableModel);
        // 在此处添加设置列宽的代码
        TableColumnModel columnModel = table.getTableHeader().getColumnModel();
        columnModel.getColumn(0).setPreferredWidth(columnModel.getColumn(0).getPreferredWidth() * 10);
        columnModel.getColumn(1).setPreferredWidth(columnModel.getColumn(1).getPreferredWidth() * 1);
        columnModel.getColumn(2).setPreferredWidth(columnModel.getColumn(2).getPreferredWidth() * 1);

        // 获取行高度
        int originalRowHeight = table.getRowHeight();
        // 设置行高度为原来的两倍
        table.setRowHeight(originalRowHeight * 2);

        // 设置自动换行
        table.getColumnModel().getColumn(0).setCellRenderer(new MultilineTableCellRenderer());

        
        // 创建组件
        questionField = new JTextField(20);
        answerField = new JTextField(20);

        String[] questionTypes = {"单选题", "多选题", "填空题", "判断题", "主观题"};
        questionTypeComboBox = new JComboBox<>(questionTypes);

        JButton addButton = new JButton("添加题目");
        JButton deleteButton = new JButton("删除题目");
        JButton exportButton = new JButton("导出题库");
        JButton importButton = new JButton("导入题库");
        JButton showButton = new JButton("题库展示");
        JButton produceButton = new JButton("出卷界面");

        // 添加事件监听器
        addButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                addQuestion();
            }
        });

        deleteButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                deleteQuestion();
            }
        });

        exportButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                exportQuestionBank();
            }
        });

        importButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                importQuestionBank();
            }
        });
        showButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
            	showQuestionBank();
            }
        });
        produceButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
            	produceQuestionBank();
            }
        });

        // 创建布局
        JPanel functionBar1=new JPanel();
        functionBar1.setLayout(new GridLayout(20,1));
        functionBar1.add(showButton);
        functionBar1.add(produceButton);
        
        JPanel functionBar2=new JPanel();
        functionBar2.setLayout(new GridLayout(20,1));
        functionBar2.add(importButton);
        functionBar2.add(exportButton);
        
        JPanel inputPanel = new JPanel();
        inputPanel.setLayout(new GridLayout(4, 2));
        inputPanel.add(new JLabel("题目内容："));
        inputPanel.add(questionField);
        inputPanel.add(new JLabel("答案："));
        inputPanel.add(answerField);
        inputPanel.add(new JLabel("题目类型："));
        inputPanel.add(questionTypeComboBox);
        inputPanel.add(addButton);
        inputPanel.add(deleteButton);

        // 添加组件到窗口
        //采用BorderLayout
        add(new JScrollPane(table), BorderLayout.CENTER);
        add(inputPanel, BorderLayout.SOUTH);
        add(functionBar1, BorderLayout.WEST);
        add(functionBar2, BorderLayout.EAST);

        // 设置窗口属性
        setSize(1000, 800);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setVisible(true);
    }
    private void addQuestion() {
        content = questionField.getText();
        answer = answerField.getText();
        type = (String) questionTypeComboBox.getSelectedItem();
        
        System.out.println("已经添加：" );
        System.out.println("题目：" + content);
        System.out.println("答案：" + answer);
        System.out.println("类型：" + type);

        
        Question question = new Question(content, answer, type);
        questionBank.add(question);

        // 添加到表格
        tableModel.addRow(new Object[]{content, answer, type});

        clearFields();
    }

    private void deleteQuestion() {
        int selectedIndex = table.getSelectedRow();
        if (selectedIndex >= 0 && selectedIndex < questionBank.size()) {
        	 // 获取选中行的数据
            content = (String) table.getValueAt(selectedIndex, 0);
            answer = (String) table.getValueAt(selectedIndex, 1);
            type = (String) table.getValueAt(selectedIndex, 2);

            // 打印选中行的数据
            System.out.println("已经删去：" );
            System.out.println("题目：" + content);
            System.out.println("答案：" + answer);
            System.out.println("类型：" + type);

            questionBank.remove(selectedIndex);
            tableModel.removeRow(selectedIndex);
        } else {
            JOptionPane.showMessageDialog(this, "请选择要删除的题目");
        }
    }

    private void exportQuestionBank() {
        // 实现导出题库的逻辑
        // 可以使用文件选择对话框选择导出路径，并将题库信息写入文件
        JOptionPane.showMessageDialog(this, "导出题库功能待实现");
    }

    private void importQuestionBank() {
        // 实现导入题库的逻辑
        // 可以使用文件选择对话框选择导入文件，并读取文件中的题库信息
    	String sql = null;
    	int selectedIndex = table.getSelectedRow();
        if (selectedIndex >= 0 && selectedIndex < questionBank.size()) {
        	 // 获取选中行的数据
            content = (String) table.getValueAt(selectedIndex, 0);
            answer = (String) table.getValueAt(selectedIndex, 1);
            type = (String) table.getValueAt(selectedIndex, 2);
            switch(answer.toLowerCase()) {
	            case("a"):{
	            	sql="INSERT INTO multiple_choice (topic, answer) VALUES('"+content+"', 'A');";
	            	break;
	            }
	            case("b"):{
	            	sql="INSERT INTO multiple_choice (topic, answer) VALUES('"+content+"', 'B');";
	            	break;
	            }	
				case("c"):{
					sql="INSERT INTO multiple_choice (topic, answer) VALUES('"+content+"', 'C');";
					break;
	            }	
				case("d"):{
					sql="INSERT INTO multiple_choice (topic, answer) VALUES('"+content+"', 'D');";
					break;
	            }
            }
            try {
				con.insert(sql);
			} catch (SQLException e) {
				// TODO 自动生成的 catch 块
				e.printStackTrace();
			}
            JOptionPane.showMessageDialog(this, "导入题库成功");
        }else {
	        JOptionPane.showMessageDialog(this, "请选择要导入题库的题目");
	    }
    }
    
    private void showQuestionBank() {
        //展示题库
    	new QuestionBankDisplay();
        JOptionPane.showMessageDialog(this, "展示题库功能待实现");
    }
    
    private void produceQuestionBank() {
        //出卷响应
        JOptionPane.showMessageDialog(this, "出卷功能待实现");
    }
    
    private void clearFields() {
        questionField.setText("");
        answerField.setText("");
        questionTypeComboBox.setSelectedIndex(0);
    }
    
    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new QuestionBankManagementSystem();
            }
        });
    }

}


